<?php
$passwords = [123, 'user', 'toor'];